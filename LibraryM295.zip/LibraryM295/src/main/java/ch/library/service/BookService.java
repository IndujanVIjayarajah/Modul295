
package ch.library.service;

import java.util.List;
import org.springframework.stereotype.Service;
import ch.library.model.Book;
import ch.library.repository.BookRepository;

@Service
public class BookService {

 private final BookRepository repo;

 public BookService(BookRepository repo) {
  this.repo = repo;
 }

 public List<Book> findAll() { return repo.findAll(); }
 public Book save(Book b) { return repo.save(b); }
 public Book update(Book b) { return repo.save(b); }
 public void delete(Long id) { repo.deleteById(id); }
}
