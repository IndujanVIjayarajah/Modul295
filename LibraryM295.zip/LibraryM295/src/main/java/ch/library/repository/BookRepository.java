
package ch.library.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ch.library.model.Book;

public interface BookRepository extends JpaRepository<Book, Long> {}
