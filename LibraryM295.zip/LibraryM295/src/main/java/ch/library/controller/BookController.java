
package ch.library.controller;

import java.util.List;
import org.springframework.web.bind.annotation.*;
import ch.library.model.Book;
import ch.library.service.BookService;

@RestController
@RequestMapping("/books")
public class BookController {

 private final BookService service;

 public BookController(BookService service) {
  this.service = service;
 }

 @GetMapping
 public List<Book> getAll() {
  return service.findAll();
 }

 @PostMapping
 public Book create(@RequestBody Book book) {
  return service.save(book);
 }

 @PutMapping
 public Book update(@RequestBody Book book) {
  return service.update(book);
 }

 @DeleteMapping("/{id}")
 public void delete(@PathVariable Long id) {
  service.delete(id);
 }
}
