package ch.library.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import ch.library.model.Book;
import ch.library.repository.BookRepository;

@ExtendWith(MockitoExtension.class)
class BookServiceTest {

    @Mock
    private BookRepository bookRepository;

    @InjectMocks
    private BookService bookService;

    @Test
    void shouldReturnAllBooks() {
        // Arrange
        Book book = new Book();
        book.setTitle("Clean Code");
        book.setAuthor("Robert C. Martin");

        when(bookRepository.findAll()).thenReturn(List.of(book));

        // Act
        List<Book> result = bookService.findAll();

        // Assert
        assertEquals(1, result.size());
        assertEquals("Clean Code", result.get(0).getTitle());
    }

    @Test
    void shouldSaveBook() {
        // Arrange
        Book book = new Book();
        book.setTitle("Refactoring");
        book.setAuthor("Martin Fowler");

        when(bookRepository.save(book)).thenReturn(book);

        // Act
        Book savedBook = bookService.save(book);

        // Assert
        assertNotNull(savedBook);
        verify(bookRepository, times(1)).save(book);
    }
}
